#!/bin/bash
javac -cp lib/program.jar:. GenerateurSite.java
