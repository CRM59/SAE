#!/bin/bash
javac -cp lib/program.jar:. GenerateurProduit.java
